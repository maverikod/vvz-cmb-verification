
import numpy as np, json, os, math, argparse, csv

def read_xi(path):
    if os.path.exists(path):
        r, xi = np.loadtxt(path, delimiter=",", skiprows=1).T
    else:
        # synthetic: xi(r) = A r^-2 cos(2π r / L) + noise
        rng = np.random.default_rng(0)
        r = np.linspace(1.0, 100.0, 400)
        L = 23.0
        A = 5e-4
        xi = A*(r**-2.0)*np.cos(2*np.pi*r/L + 0.2) + rng.normal(0, A*0.2*(r**-2.0), size=r.size)
    return r, xi

def fit_L(r, xi, L_guess=23.0, L_range=(10.0, 60.0), ngrid=400):
    # Detrend envelope ~ r^-2 by multiplying
    w = (r**2)*xi
    w -= w.mean()
    Ls = np.linspace(L_range[0], L_range[1], ngrid)
    best = None; best_sse = 1e99
    for L in Ls:
        c = np.cos(2*np.pi*r/L); s = np.sin(2*np.pi*r/L)
        A = np.vstack([c,s]).T
        coef, _, _, _ = np.linalg.lstsq(A, w, rcond=None)
        fit = A@coef
        sse = np.sum((w-fit)**2)
        if sse < best_sse:
            best_sse = sse; best = (L, coef, sse)
    L_fit, coef, sse = best
    amp = float(np.sqrt(coef[0]**2 + coef[1]**2)) / (np.median(r)**2)
    return float(L_fit), float(amp), float(sse)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xi", default="data/xi_of_r.csv")
    ap.add_argument("--out", default="outputs/xi_match.json")
    args = ap.parse_args()
    r, xi = read_xi(args.xi)
    L_fit, amp, sse = fit_L(r, xi)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"L_fit_Mpc": L_fit, "amp_ref": amp, "sse": sse}, f, ensure_ascii=False, indent=2)
    print(json.dumps({"L_fit_Mpc": L_fit, "amp_ref": amp}))

if __name__=="__main__":
    main()
