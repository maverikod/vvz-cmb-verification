#!/usr/bin/env python
import os
import pathlib
import urllib.request

ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent

def safe_download(url: str, path: pathlib.Path):
    print(f"[DOWNLOAD] {url} -> {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        urllib.request.urlretrieve(url, path)
    except Exception as e:
        print(f"  !! failed: {e}")
        print("  NOTE: URL might have changed; open it in browser and adjust this script.")

def main():
    # Strong lensing
    lens_dir = ROOT_DIR / "data_sources" / "lensing"
    # Example placeholders (must be updated by hand):
    # safe_download("https://some.slacs.org/path/to/slacs_catalog.dat",
    #               lens_dir / "slacs_catalog.dat")

    # SNe Ia: Pantheon+
    sn_dir = ROOT_DIR / "data_sources" / "supernovae"
    # Example placeholder URL from Pantheon+ GitHub (check actual path/name):
    # safe_download(
    #     "https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/PantheonPlusSH0ES.dat",
    #     sn_dir / "pantheon_plus_raw.dat"
    # )

    # BAO: BOSS/eBOSS DR16
    bao_dir = ROOT_DIR / "data_sources" / "bao"
    # Example placeholder:
    # safe_download(
    #     "https://data.sdss.org/sas/dr16/eboss/BAO/your_bao_file_here.fits",
    #     bao_dir / "dr16_bao_data.fits"
    # )

    print("Done (placeholders). Edit URLs, uncomment safe_download(...) calls and rerun.")

if __name__ == "__main__":
    main()
