
import numpy as np, json, os, math, argparse

def ring_filter_fft(img, k0_pix, bw_pix):
    F = np.fft.rfft2(img)
    ny, nx = img.shape
    ky = np.fft.rfftfreq(ny)*2*np.pi
    kx = np.fft.rfftfreq(nx)*2*np.pi  # rfft2 uses rfftfreq for x as well
    Ky, Kx = np.meshgrid(ky, kx, indexing='ij')
    K = np.sqrt(Kx**2 + Ky**2)
    W = np.exp(-0.5*((K-k0_pix)/bw_pix)**2)
    return np.fft.irfft2(F*W, s=img.shape)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kappa_map", default="data/kappa_map.npy")
    ap.add_argument("--lss_map", default="data/lss_map.npy")
    ap.add_argument("--out", default="outputs/xmap_ring.json")
    ap.add_argument("--k0_pix", type=float, default=30.0)
    ap.add_argument("--bw_pix", type=float, default=6.0)
    args = ap.parse_args()
    # load or synthesize
    if os.path.exists(args.kappa_map) and os.path.exists(args.lss_map):
        K = np.load(args.kappa_map); G = np.load(args.lss_map)
    else:
        # synthetic maps: common ring mode + noise
        rng = np.random.default_rng(0)
        ny, nx = 256, 256
        K = rng.normal(0,1,(ny,nx)); G = rng.normal(0,1,(ny,nx))
        # add a common ring-like pattern
        y = np.linspace(-1,1,ny); x = np.linspace(-1,1,nx)
        X,Y = np.meshgrid(x,y); R = np.sqrt(X**2+Y**2)
        ring = np.cos(40*R)
        K += 0.3*ring; G += 0.2*ring
    Kf = ring_filter_fft(K, args.k0_pix, args.bw_pix)
    Gf = ring_filter_fft(G, args.k0_pix, args.bw_pix)
    # cross-correlation coefficient
    kc = (Kf - Kf.mean()).flatten(); gc = (Gf - Gf.mean()).flatten()
    r = float(np.dot(kc, gc) / (np.linalg.norm(kc)*np.linalg.norm(gc) + 1e-12))
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump({"ring_corr_coeff": r}, f, ensure_ascii=False, indent=2)
    print(json.dumps({"ring_corr_coeff": r}))

if __name__=="__main__":
    main()
