SPARC-resonator analysis: first verification step

1. Data used
   - observed_plateau_slopes_per_cluster.csv: plateau slopes and flatness for 9 SPARC clusters.
   - fit_vs_observed_rmse_per_cluster.csv: RMSE/MAE/MaxAE of resonator fits per cluster.
   - Lphi_per_cluster.csv: characteristic lengthscale Lphi vs Rmax.
   - dct_rmse_summary.csv, dct_first64_coeffs.csv: DCT-based shape compression per cluster.
   - mass_shapes_all_clusters_combined.csv: dimensionless mass/velocity profiles per cluster.
   - observed_plateau_summary.csv: global medians of plateau slopes/flatness.

2. Implemented checks (this code run)
   2.1. Clustering of central plateau slopes across 9 clusters into 3 groups (k-means in 4D
        space of slopes 0.6–0.8, 0.7–0.9, 0.8–1.0, 0.9–1.1).
        → This is the first proxy for three resonant families U1/U2/U3.

   2.2. For each cluster we attach:
        - Full set of plateau slopes.
        - Fit quality (RMSE, MAE, MaxAE) of resonator-based V_model vs V_obs.
        - Lphi_over_Rmax as a proxy for resonant radius vs outer size.
        - Effective DCT truncation K_star (number of cosine modes needed to approx. the profile)
          from dct_rmse_summary.csv.

   2.3. We compute group-wise statistics for the 3 resonance-like groups:
        - mean / std of plateau slope 0.8–1.0 (core of the plateau),
        - mean / std of fit RMSE,
        - mean / std of K_star,
        - mean / std of Lphi_over_Rmax.

3. How this maps to the chapter
   - 3 plateau families vs. U1/U2/U3:
     The groups in slope-space correspond to different effective shapes of V(R)
     and thus to different dominant (n1,n2,n3), as described in the resonator chapter.

   - RMSE by group:
     If the groups are physical (resonant) families, fit quality and required DCT complexity
     should systematically differ between them.

   - Lphi_over_Rmax by group:
     This probes the link between resonant radius of the defect and outer observable size.

4. Next steps (not implemented yet in this script)
   - Invert the DCT spectra per cluster to an effective radial k-grid and solve the discrete
     minimization problem for (n1,n2,n3) given fixed R_j, as outlined in the chapter.
   - Attach tentative (n1,n2,n3; m; p) labels to each cluster and compare with morphology
     if/when external catalogues are linked.
   - Extend from 9 cluster-averaged profiles to per-galaxy SPARC entries using the
     calibration_outputs/per_cluster_*.csv tables.

Files produced by this run
   - cluster_resonator_summary.csv: per-cluster table with all joined metrics and 3-group labels.
   - cluster_resonator_group_stats.csv: compact stats for the 3 groups.
