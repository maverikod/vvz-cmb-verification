# Cells ↔ LSS correlation (v1)

Build: 2025-11-08 14:35 UTC

Goal: test whether the micro-cell scale inferred from CMB (Δθ_1/2 ≈ 2.82′ → L_full ≈ 23.0 Mpc) correlates with **large-scale structure** statistics:
- ring-like feature in 3D **P(k)** at k0 ≈ 0.274 1/Mpc (≈ 0.391 h/Mpc),
- quasi-periodic component in **xi(r)** with period ≈ L_full,
- link to **void/wall** geometry (void radius distribution around ~L_half..L_full),
- cross with **CMB lensing κ** (preferred ℓ ≈ κ_rad ≈ 3829) using a narrowband ring filter.

## Inputs (optional; if missing, synthetic demo is used)
- `data/xi_of_r.csv`           : columns `r, xi` (r in Mpc or Mpc/h, auto-detected)
- `data/Pk.csv`                : columns `k, P`  (k in 1/Mpc or h/Mpc, auto-detected)
- `data/voids.csv`             : columns `Reff`  (effective radius, Mpc or Mpc/h)
- `data/kappa_map.npy`         : ring-filtered CMB lensing κ-map (optional, 2D array), or placeholder
- `data/lss_map.npy`           : projected LSS overdensity map (same resolution as κ-map)

## What it does
- `xi_match.py`  : fits a template A r^-2 cos(2π r / L) + C to xi(r) after detrending; reports best L near the predicted L_full.
- `Pk_ring.py`   : whitens P(k) by smooth baseline and measures SNR in a band around k0.
- `voids_check.py`: compares void radius histogram with [L_half, L_full]; reports alignment of modes/medians.
- `xmap_ring.py` : demonstrates a narrowband ring filter in Fourier space for 2D maps and outputs cross-correlation coefficient.

Results go to `outputs/`.

## Minimal run (synthetic demo)
python code/xi_match.py
python code/Pk_ring.py
python code/voids_check.py
python code/xmap_ring.py

Replace CSV/NPY files with real data to get actual numbers.
