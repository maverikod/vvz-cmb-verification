#!/usr/bin/env bash
set -e

# Root directory of the project (this script assumes it is run from the project root)
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

###############################################################################
# 1) Strong lensing catalogs (SLACS / BELLS / DES / COSMOS)
###############################################################################

LENS_DIR="$ROOT_DIR/data_sources/lensing"
mkdir -p "$LENS_DIR"

echo "[LENSING] NOTE: URLs are examples; please verify them manually before running."

# --- SLACS (example placeholder URL) ---
# Original project: https://www.slacs.org/
# Bolton et al. 2008, ApJ 682, 964
# Example: download a machine-readable table if provided.
# wget -O "$LENS_DIR/slacs_catalog.dat" "https://some.slacs.org/path/to/slacs_catalog.dat"

# --- BELLS / BELLS GALLERY (BOSS) ---
# Project: https://lensing.sdss.org
# Example placeholder:
# wget -O "$LENS_DIR/bells_catalog.dat" "https://some.sdss.org/path/to/bells_catalog.dat"

# --- DES Strong Lensing ---
# Project: https://des.ncsa.illinois.edu/releases/other/strong-lensing
# Example placeholder:
# wget -O "$LENS_DIR/des_strong_lensing.fits" "https://des.ncsa.illinois.edu/some/path/des_strong_lensing.fits"

# --- COSMOS Strong Lensing ---
# Example placeholder:
# wget -O "$LENS_DIR/cosmos_strong_lensing.dat" "https://some.cosmos.org/path/to/cosmos_lenses.dat"

###############################################################################
# 2) SNe Ia: Pantheon+
###############################################################################

SN_DIR="$ROOT_DIR/data_sources/supernovae"
mkdir -p "$SN_DIR"

echo "[SN] Downloading Pantheon+ example (check URL)."

# Pantheon+ GitHub: https://github.com/PantheonPlusSH0ES/DataRelease
# Common file names include something like:
#   'lcparam_full_long.txt' or 'Pantheon+SH0ES.dat'
# Example placeholder:
# wget -O "$SN_DIR/pantheon_plus_raw.dat" \
#   "https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/PantheonPlusSH0ES.dat"

###############################################################################
# 3) BAO: BOSS/eBOSS DR16, 6dF, WiggleZ
###############################################################################

BAO_DIR="$ROOT_DIR/data_sources/bao"
mkdir -p "$BAO_DIR"

echo "[BAO] Downloading BAO DR16 example (check URL)."

# DR16 BAO data products:
#   https://data.sdss.org/sas/dr16/eboss/BAO/
# Example placeholder:
# wget -O "$BAO_DIR/dr16_bao_data.fits" \
#   "https://data.sdss.org/sas/dr16/eboss/BAO/your_bao_file_here.fits"

# 6dF / WiggleZ can be added similarly.

echo "Done. Now run the processing scripts:"
echo "  python scripts/process_lensing_to_sigma_crit.py"
echo "  python scripts/process_sn_pantheon.py"
echo "  python scripts/process_bao_dr16.py"
