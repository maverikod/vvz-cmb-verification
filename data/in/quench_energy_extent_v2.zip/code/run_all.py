
import os, json, math, argparse, numpy as np

C = 299792458.0
MPC = 3.085677581491367e22
HBAR = 6.582119569e-16  # eV*s

def core_numbers(kappa_deg, DM_Mpc, dkfrac):
    # half-period angle (rad), comoving lengths, k0 and Δk
    Delta_theta_half_rad = math.pi / kappa_deg * (math.pi/180.0)
    L_half = DM_Mpc * Delta_theta_half_rad
    L_full = 2.0 * L_half
    k0 = 2.0*math.pi / max(L_full,1e-30)
    dk = dkfrac * k0
    delta_comov = 1.0 / max(dk,1e-30)
    return Delta_theta_half_rad, L_half, L_full, k0, dk, delta_comov

def tau_energy(z_list, delta_comov, vfrac):
    out = []
    for z in z_list:
        a = 1.0/(1.0+z)
        delta_phys_Mpc = delta_comov * a
        tau_s = (delta_phys_Mpc*MPC) / (max(vfrac,1e-12)*C)
        E_eV_upper = HBAR / max(tau_s, 1e-30)  # since tau is a lower bound
        out.append({"z": z, "delta_phys_kpc": float(delta_phys_Mpc*1e3),
                    "tau_lower_s": float(tau_s), "tau_lower_years": float(tau_s/31557600.0),
                    "E_upper_eV": float(E_eV_upper)})
    return out

def ang_sep_deg(lon1, lat1, lon2, lat2):
    # spherical law of cosines
    d2r = math.pi/180.0
    l1, b1, l2, b2 = lon1*d2r, lat1*d2r, lon2*d2r, lat2*d2r
    return 180.0/math.pi * math.acos(max(-1.0, min(1.0,
        math.sin(b1)*math.sin(b2) + math.cos(b1)*math.cos(b2)*math.cos(l1-l2))))

def coherence_from_patches(patches, rel_thresh=0.05, min_pairs=20, nbins=12):
    # Build structure function D(θ) = < |Δκ| / κ̄ >_pairs ; find θ where it exceeds rel_thresh
    # Patches: list of dicts with lon,lat,kappa
    import numpy as np
    n = len(patches)
    if n < 4:
        return {"theta_coh_deg": None, "n_pairs": 0}
    # pairwise
    ths, ds = [], []
    for i in range(n):
        for j in range(i+1, n):
            lon1, lat1, k1 = patches[i]["lon_deg"], patches[i]["lat_deg"], patches[i]["kappa_deg"]
            lon2, lat2, k2 = patches[j]["lon_deg"], patches[j]["lat_deg"], patches[j]["kappa_deg"]
            if not (np.isfinite(k1) and np.isfinite(k2)): continue
            th = ang_sep_deg(lon1, lat1, lon2, lat2)
            d = abs(k1-k2) / max(0.5*(abs(k1)+abs(k2)), 1e-30)
            ths.append(th); ds.append(d)
    ths = np.array(ths); ds = np.array(ds)
    if len(ths) < min_pairs:
        return {"theta_coh_deg": None, "n_pairs": int(len(ths))}
    # bin by θ
    bins = np.linspace(0, ths.max(), nbins+1)
    mids = 0.5*(bins[:-1]+bins[1:]); vals = []
    for a,b in zip(bins[:-1], bins[1:]):
        sel = (ths>=a)&(ths<b)
        if sel.sum()>0:
            vals.append((0.5*(a+b), float(ds[sel].mean())))
    if not vals:
        return {"theta_coh_deg": None, "n_pairs": int(len(ths))}
    # coherence angle = largest θ where mean rel drift remains below threshold
    theta_coh = None
    for theta, mean_d in vals:
        if mean_d <= rel_thresh:
            theta_coh = theta
        else:
            break
    return {"theta_coh_deg": theta_coh, "n_pairs": int(len(ths)), "profile": vals}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--patches", default=None)
    ap.add_argument("--out", default="outputs/summary.json")
    args = ap.parse_args()

    with open(args.config,"r",encoding="utf-8") as f:
        cfg = json.load(f)
    kappa_deg = cfg["kappa_deg"]; DM_Mpc = cfg["DM_Mpc"]; dkfrac = cfg["delta_k_over_k"]; vfrac = cfg["v_frac"]; z_list = cfg["z_list"]

    Dth, Lh, Lf, k0, dk, delta_comov = core_numbers(kappa_deg, DM_Mpc, dkfrac)
    z_items = tau_energy(z_list, delta_comov, vfrac)
    out = {
        "kappa_deg": kappa_deg,
        "DM_Mpc": DM_Mpc,
        "Delta_theta_half_arcmin": float((Dth*180.0/math.pi)*60.0),
        "L_half_comov_Mpc": float(Lh),
        "L_full_comov_Mpc": float(Lf),
        "k0_1_per_Mpc": float(k0),
        "dk_over_k": dkfrac,
        "delta_comov_Mpc": float(delta_comov),
        "v_frac": vfrac,
        "z_solutions": z_items
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    # coherence
    coh = {"theta_coh_deg": None, "n_pairs": 0}
    if args.patches and os.path.exists(args.patches):
        import csv
        patches = []
        with open(args.patches,"r",encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                try:
                    patches.append({
                        "lon_deg": float(r.get("lon_deg", r.get("lon", r.get("ra_deg", 0)))),
                        "lat_deg": float(r.get("lat_deg", r.get("lat", r.get("dec_deg", 0)))),
                        "kappa_deg": float(r.get("kappa_deg", r.get("kappa", r.get("k", "nan"))))
                    })
                except Exception:
                    pass
        coh = coherence_from_patches(patches, rel_thresh=0.05, min_pairs=20, nbins=12)
        # Map θ_coh to L_coh_min
        if coh.get("theta_coh_deg") is not None:
            theta_rad = coh["theta_coh_deg"] * math.pi/180.0
            coh["L_coh_min_Mpc"] = float(DM_Mpc * theta_rad)
    with open("outputs/coherence.json","w",encoding="utf-8") as f:
        json.dump(coh, f, ensure_ascii=False, indent=2)

    # short note
    with open("outputs/notes.txt","w",encoding="utf-8") as f:
        f.write("E_upper is an upper bound from ħ/τ_lower; τ_lower grows for smaller v_frac.\n")
        f.write("If θ_coh is large (tens of degrees) with small relative drift, then L_coh_min ~ D_M * θ_coh implies a quench region coherent over a substantial fraction of the LSS.\n")

if __name__=="__main__":
    main()
