
import json, math, argparse, os
import numpy as np

C = 299792458.0            # m/s
MPC = 3.085677581491367e22 # meters
HBAR = 6.582119569e-16     # eV*s

def compute_from_config(cfg):
    kappa_deg = cfg["kappa_deg"]
    DM_Mpc = cfg["DM_Mpc"]
    dkfrac = cfg["delta_k_over_k"]
    vfrac = cfg["v_frac"]
    z_list = cfg["z_list"]

    # Angular half-period (rad)
    Delta_theta_half_rad = math.pi / kappa_deg * (math.pi/180.0)  # careful: kappa in deg^-1
    # Comoving lengths
    L_half = DM_Mpc * Delta_theta_half_rad
    L_full = 2.0 * L_half
    # 3D k0
    k0 = 2.0*math.pi / L_full   # 1/Mpc
    # width and domain-wall thickness
    dk = dkfrac * k0
    delta_comov = 1.0 / max(dk, 1e-30)  # Mpc
    out = {
        "kappa_deg": kappa_deg,
        "DM_Mpc": DM_Mpc,
        "Delta_theta_half_arcmin": float( (Delta_theta_half_rad*180.0/math.pi)*60.0 ),
        "L_half_comov_Mpc": float(L_half),
        "L_full_comov_Mpc": float(L_full),
        "k0_1_per_Mpc": float(k0),
        "dk_over_k": dkfrac,
        "delta_comov_Mpc": float(delta_comov),
        "v_frac": vfrac,
        "z_solutions": []
    }
    for z in z_list:
        a = 1.0/(1.0+z)
        L_half_phys = L_half * a
        L_full_phys = L_full * a
        delta_phys = delta_comov * a
        tau_lower_s = (delta_phys*MPC) / (max(vfrac,1e-12)*C)
        tau_lower_yr = tau_lower_s / (3600.0*24.0*365.25)
        E_eV = HBAR / max(tau_lower_s, 1e-30)
        out["z_solutions"].append({
            "z": z,
            "L_half_phys_kpc": float(L_half_phys*1e3),
            "L_full_phys_kpc": float(L_full_phys*1e3),
            "delta_phys_kpc": float(delta_phys*1e3),
            "tau_lower_seconds": float(tau_lower_s),
            "tau_lower_years": float(tau_lower_yr),
            "E_q_eV_notional": float(E_eV)
        })
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default="outputs/results.json")
    args = ap.parse_args()
    with open(args.config,"r",encoding="utf-8") as f:
        cfg = json.load(f)
    res = compute_from_config(cfg)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(json.dumps({"L_full_comov_Mpc": res["L_full_comov_Mpc"], "delta_comov_Mpc": res["delta_comov_Mpc"]}))

if __name__=="__main__":
    main()
