
import numpy as np
from dataclasses import dataclass
from core_geometry import CoreParams

@dataclass
class ResonatorWalls:
    r_in: float
    r_out: float
    R_in: float
    R_out: float
    alpha_in: float
    alpha_out: float
    Q: float

def _soft_wall_radius(R_inner: float, R_mid: float, R_outer: float) -> float:
    """
    Heuristic: place inner wall slightly inside inner torus, outer wall slightly
    outside outer torus.
    """
    r_in = 0.8 * R_inner
    r_out = 1.1 * R_outer
    return r_in, r_out

def _alpha_from_width(dR: float, kappa: float, scale: float = 0.5) -> float:
    """
    Map torus width and stiffness to an effective damping coefficient alpha.
    Narrow & stiff torus -> small alpha (weak loss, high reflection).
    Wide or soft -> larger alpha.
    """
    dR_eff = max(dR, 1e-3)
    k_eff = max(kappa, 1e-3)
    return scale * (dR_eff / k_eff)

def compute_resonator_walls(core: CoreParams) -> ResonatorWalls:
    """
    Compute effective resonator walls and reflection coefficients from core.

    This is a simplified 1D model along radius in the main disk plane.
    """
    R1, R2, R3 = core.sorted_radii()
    # Effective inner/outer wall positions
    r_in, r_out = _soft_wall_radius(R1, R2, R3)
    # Effective damping at inner and outer walls from T1 and T3
    alpha_in = _alpha_from_width(core.T1.dR, core.T1.kappa)
    alpha_out = _alpha_from_width(core.T3.dR, core.T3.kappa)
    # Reflection coefficients
    R_in = float(np.exp(-alpha_in))
    R_out = float(np.exp(-alpha_out))
    # Combined Q-factor
    product = max(min(R_in * R_out, 0.9999), 0.0)
    if product >= 1.0:
        Q = 1e6
    else:
        Q = float(np.pi / (1.0 - product))
    return ResonatorWalls(
        r_in=r_in,
        r_out=r_out,
        R_in=R_in,
        R_out=R_out,
        alpha_in=alpha_in,
        alpha_out=alpha_out,
        Q=Q,
    )

def radial_modes(r: np.ndarray, walls: ResonatorWalls, n_modes: int = 3) -> np.ndarray:
    """
    Construct simple sine-like radial eigenmodes between r_in and r_out.

    r : 1D array of radii.
    Returns array shape (n_modes, len(r)).
    """
    r = np.asarray(r, dtype=float)
    mask = (r >= walls.r_in) & (r <= walls.r_out)
    x = np.zeros_like(r)
    # Map working interval [r_in, r_out] -> [0, 1]
    denom = max(walls.r_out - walls.r_in, 1e-6)
    x[mask] = (r[mask] - walls.r_in) / denom

    modes = []
    for n in range(1, n_modes + 1):
        # Basic mode shape
        phi = np.sin(n * np.pi * x)
        # Simple envelope: decay outside the walls
        phi[r < walls.r_in] = phi[mask][0] * np.exp(-(walls.r_in - r[r < walls.r_in]) / denom)
        phi[r > walls.r_out] = phi[mask][-1] * np.exp(-(r[r > walls.r_out] - walls.r_out) / denom)
        modes.append(phi)
    return np.array(modes)

def mode_amplitudes_least_squares(modes: np.ndarray, V_obs: np.ndarray) -> np.ndarray:
    """
    Fit amplitudes A_n for modes to approximate V_obs(r) in least-squares sense.

    modes: (n_modes, N)
    V_obs: (N,)
    Returns: (n_modes,)
    """
    M = modes.T  # shape (N, n_modes)
    V = np.asarray(V_obs, dtype=float)
    # Solve M * a ≈ V in least squares sense
    a, *_ = np.linalg.lstsq(M, V, rcond=None)
    return a

def effective_mode_amplitudes(amplitudes: np.ndarray, walls: ResonatorWalls) -> np.ndarray:
    """
    Apply a simple geometric-series enhancement to raw amplitudes using wall reflections.
    """
    product = walls.R_in * walls.R_out
    product = max(min(product, 0.9999), 0.0)
    factor = 1.0 / (1.0 - product)
    return amplitudes * factor

def rotation_curve_from_core(core: CoreParams, r: np.ndarray, V_obs: np.ndarray = None,
                             n_modes: int = 3):
    """
    Build a model rotation curve from core parameters.

    If V_obs is provided, fit raw mode amplitudes by least squares to V_obs.
    Otherwise, use a simple decaying sequence of amplitudes.
    """
    walls = compute_resonator_walls(core)
    modes = radial_modes(r, walls, n_modes=n_modes)

    if V_obs is not None:
        A_raw = mode_amplitudes_least_squares(modes, V_obs)
    else:
        A_raw = np.array([1.0 / n for n in range(1, n_modes + 1)], dtype=float)

    A_eff = effective_mode_amplitudes(A_raw, walls)
    V_model = np.dot(A_eff, modes)
    return V_model, walls, modes, A_raw, A_eff
