# Θ-background cosmology data pipeline

This archive contains a **minimal, reproducible skeleton** for downloading and preprocessing
external cosmological datasets needed to calibrate the Θ-background on the level of ΛCDM:

* strong lensing (SLACS / BELLS / DES / COSMOS);
* SN Ia (Pantheon+);
* BAO (BOSS/eBOSS DR16, optional 6dF + WiggleZ).

> NOTE:
> 1. The archive does **not** contain the external data themselves (they are large and under
>    their own licenses).
> 2. All scripts are written to be as self-explanatory as possible, but you **must check**
>    the actual URLs and filenames on the official sites; paths can change with time.
> 3. Everything is designed so that Θ-code can later read a single set of unified CSV files:
>    - `data_sources/lensing/sigma_crit_per_lens.csv`
>    - `data_sources/supernovae/pantheon_plus_hubble_diagram.csv`
>    - `data_sources/bao/bao_distance_measurements.csv`

## Structure

- `scripts/`
  - `download_data.sh` — shell script with `wget` commands grouped by dataset.
  - `download_data.py` — Python downloader (alternative to the shell script).
  - `process_lensing_to_sigma_crit.py` — converts survey lens catalogs into
    a unified `sigma_crit_per_lens.csv`.
  - `process_sn_pantheon.py` — converts Pantheon+ tables into a compact
    Hubble diagram CSV.
  - `process_bao_dr16.py` — parses BAO DR16 data into a unified format
    for Θ-background calibration.

- `data_sources/`
  - `lensing/` — raw + processed strong lensing data.
  - `supernovae/` — raw + processed SN Ia data.
  - `bao/` — raw + processed BAO data.

- `config/`
  - `theta_background_config.yaml` — high-level config with paths and a few
    Θ-parameters hooks (to be read by later Θ-cosmology code).

- `notebooks/`
  - empty, reserved for your local exploratory analysis.

## Minimal workflow

1. Edit `scripts/download_data.sh` (or `download_data.py`) if needed.
2. Run downloads:
   ```bash
   cd theta_background_data_pipeline
   bash scripts/download_data.sh
   # or:
   python scripts/download_data.py
   ```
3. Process each dataset:
   ```bash
   python scripts/process_lensing_to_sigma_crit.py
   python scripts/process_sn_pantheon.py
   python scripts/process_bao_dr16.py
   ```
4. Use the resulting CSV files in your Θ-background calibration code.

All numeric calibration of the Θ-background to ΛCDM-level observables
(H(z), D_L(z), D_A(z), BAO scale, etc.) can be built on top of these unified CSVs.
