# Quench energy & spatial extent from oscillatory structure (v2)

Build: 2025-11-08 14:46 UTC

## What this estimates
- **Domain scale**: L_full = 2 * (π/κ_* ) * D_M
- **Wall thickness** (comoving): δ ≈ 1 / Δk, with Δk = (Δk/k0) * k0, k0 = 2π/L_full
- **Quench duration lower bound**: τ_q(z) ≥ [ a(z) δ ] / [ v_frac c ], a=1/(1+z)
- **Energy scale upper bound**: E_q ≤ ħ / τ_q  (since τ_q is a lower bound)
- **Angular coherence** of κ_*(n̂) from patch map → **L_coh_min** = D_M * θ_coh

## Inputs
- `config.json` with: kappa_deg, DM_Mpc, dkfrac (Δk/k0), vfrac, z_list
- Optional: `data/kappa_patches.csv` with columns: lon_deg, lat_deg, kappa_deg, kappa_err (any subset; errs optional)

## Outputs
- `outputs/summary.json` — all derived numbers
- `outputs/coherence.json` — θ_coh lower bound (deg) and L_coh_min (Mpc)
- `outputs/notes.txt` — short interpretation

Run:
    python code/run_all.py --config config.json --patches data/kappa_patches.csv
If patches file missing, the script reports only energy/δ/τ items.
