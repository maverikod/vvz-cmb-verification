import os
import numpy as np
import pandas as pd

def kmeans_nd(X, k=3, n_init=20, n_iter=100, random_state=42):
    rng = np.random.default_rng(random_state)
    best_inertia = None
    best_centroids = None
    best_labels = None
    n_samples = X.shape[0]

    for _ in range(n_init):
        idx = rng.choice(n_samples, size=k, replace=False)
        centroids = X[idx].copy()

        for _ in range(n_iter):
            dists = np.linalg.norm(X[:, None, :] - centroids[None, :, :], axis=2)
            labels = np.argmin(dists, axis=1)
            new_centroids = np.vstack([
                X[labels == j].mean(axis=0) if np.any(labels == j) else centroids[j]
                for j in range(k)
            ])
            if np.allclose(new_centroids, centroids):
                centroids = new_centroids
                break
            centroids = new_centroids

        inertia = np.sum((X - centroids[labels]) ** 2)
        if best_inertia is None or inertia < best_inertia:
            best_inertia = inertia
            best_centroids = centroids.copy()
            best_labels = labels.copy()

    return best_centroids, best_labels, best_inertia

def run_analysis(base_dir):
    slopes_df = pd.read_csv(os.path.join(base_dir, "observed_plateau_slopes_per_cluster.csv"))
    rmse_df = pd.read_csv(os.path.join(base_dir, "fit_vs_observed_rmse_per_cluster.csv"))
    Lphi_df = pd.read_csv(os.path.join(base_dir, "Lphi_per_cluster.csv"))
    dct_rmse_df = pd.read_csv(os.path.join(base_dir, "dct_rmse_summary.csv"))
    plateau_summary_df = pd.read_csv(os.path.join(base_dir, "observed_plateau_summary.csv"))

    features_cols = [
        "slope_0.6_0.8",
        "slope_0.7_0.9",
        "slope_0.8_1.0",
        "slope_0.9_1.1",
    ]
    X = slopes_df[features_cols].values.astype(float)
    centroids, labels, inertia = kmeans_nd(X, k=3)

    dct_best = (
        dct_rmse_df.sort_values(["cluster_col", "RMSE"])
        .groupby("cluster_col")
        .first()
        .reset_index()
        .rename(columns={"K": "K_star", "RMSE": "DCT_RMSE"})
    )

    summary = slopes_df.copy()
    summary["group_label"] = labels
    summary = summary.merge(rmse_df[["cluster", "RMSE", "MAE", "MaxAE"]],
                            on="cluster", how="left", suffixes=("", "_fit"))
    summary = summary.merge(Lphi_df, on="cluster", how="left", suffixes=("", "_Lphi"))
    summary["cluster_col"] = summary["cluster"].apply(lambda c: f"Cluster_{c}")
    summary = summary.merge(dct_best[["cluster_col", "K_star", "DCT_RMSE"]],
                            on="cluster_col", how="left")

    group_stats = (
        summary.groupby("group_label")
        .agg(
            n_clusters=("cluster", "count"),
            mean_slope_0_8_1_0=("slope_0.8_1.0", "mean"),
            std_slope_0_8_1_0=("slope_0.8_1.0", "std"),
            mean_RMSE=("RMSE", "mean"),
            std_RMSE=("RMSE", "std"),
            mean_K_star=("K_star", "mean"),
            std_K_star=("K_star", "std"),
            mean_Lphi_over_Rmax=("Lphi_over_Rmax", "mean"),
            std_Lphi_over_Rmax=("Lphi_over_Rmax", "std"),
        )
        .reset_index()
    )

    out_dir = os.path.join(base_dir, "sparc_resonator_analysis")
    os.makedirs(out_dir, exist_ok=True)
    summary.to_csv(os.path.join(out_dir, "cluster_resonator_summary.csv"), index=False)
    group_stats.to_csv(os.path.join(out_dir, "cluster_resonator_group_stats.csv"), index=False)

    plateau_summary = plateau_summary_df.to_dict(orient="records")[0]
    return centroids, group_stats, plateau_summary

if __name__ == "__main__":
    base_dir = os.path.dirname(__file__) or "."
    centroids, group_stats, plateau_summary = run_analysis(base_dir)
    print("Plateau summary:", plateau_summary)
    print("\nGroup stats:")
    print(group_stats)
