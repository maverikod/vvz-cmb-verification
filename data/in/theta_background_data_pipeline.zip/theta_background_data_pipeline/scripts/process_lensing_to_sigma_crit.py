#!/usr/bin/env python
"""Convert survey-specific strong lensing catalogs into a unified sigma_crit_per_lens.csv.

Input (expected in data_sources/lensing/):
  - One or more raw catalog files from SLACS / BELLS / DES / COSMOS, etc.
    Each must contain, at minimum:
      * lens ID
      * z_lens
      * z_source
      * Einstein radius R_Ein [arcsec] (optional but recommended)
      * any extra metadata you want to propagate.

Output:
  - data_sources/lensing/sigma_crit_per_lens.csv with columns:
      lens_id, survey, z_lens, z_source, R_Ein_arcsec,
      sigma_crit_SI, D_l_Mpc, D_s_Mpc, D_ls_Mpc

The cosmology / Θ-background mapping (H(z), distance-redshift) will be provided
by a separate module later. For now, this script can either:

  * use a reference ΛCDM (Planck 2018-like) for initial distances, OR
  * leave the distance-related columns empty (NaN) and only standardize z_lens/z_source.
"""

import os
import pathlib
import csv
from typing import List, Dict, Optional

ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent
LENS_DIR = ROOT_DIR / "data_sources" / "lensing"
OUT_CSV = LENS_DIR / "sigma_crit_per_lens.csv"

def parse_example_slacs(path: pathlib.Path) -> List[Dict]:
    """Example parser for a SLACS-like ASCII catalog.

    This is a placeholder; you must adapt it to the actual file format.
    """
    rows: List[Dict] = []
    if not path.exists():
        return rows

    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            parts = line.split()
            # Example: ID z_lens z_source R_Ein_arcsec ...
            try:
                lens_id = parts[0]
                z_lens = float(parts[1])
                z_src = float(parts[2])
                R_ein = float(parts[3])
            except Exception:
                continue
            rows.append(
                dict(
                    lens_id=lens_id,
                    survey="SLACS",
                    z_lens=z_lens,
                    z_source=z_src,
                    R_Ein_arcsec=R_ein,
                    sigma_crit_SI="",
                    D_l_Mpc="",
                    D_s_Mpc="",
                    D_ls_Mpc="",
                )
            )
    return rows

def main():
    LENS_DIR.mkdir(parents=True, exist_ok=True)

    all_rows: List[Dict] = []

    # Example: parse SLACS-like file (adapt name to reality)
    slacs_file = LENS_DIR / "slacs_catalog.dat"
    if slacs_file.exists():
        all_rows.extend(parse_example_slacs(slacs_file))
    else:
        print(f"[WARN] Example SLACS file not found: {slacs_file}")

    if not all_rows:
        print("No lensing rows parsed. Put raw catalogs into data_sources/lensing/ and edit parsers.")
        return

    fieldnames = [
        "lens_id",
        "survey",
        "z_lens",
        "z_source",
        "R_Ein_arcsec",
        "sigma_crit_SI",
        "D_l_Mpc",
        "D_s_Mpc",
        "D_ls_Mpc",
    ]

    with OUT_CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            writer.writerow(row)

    print(f"Wrote unified lensing catalog to: {OUT_CSV}")

if __name__ == "__main__":
    main()
