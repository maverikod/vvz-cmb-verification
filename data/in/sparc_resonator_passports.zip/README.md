# Galaxy Resonator Passports (SPARC clusters)

For each SPARC cluster (Cluster_0..Cluster_8) we construct a resonator "passport"
linking observed rotation-curve properties to the three-torus defect model.

Columns:

- cluster: cluster index (0..8).
- slope_0.8_1.0, flatness_RMS_0.8_1.0: observed plateau slope and flatness.
- Lphi_over_Rmax: dimensionless resonant depth/scale of the defect.
- SWI, Q_spec, chi6_dimless_Rmax: calibrated field / shape parameters from calibration_outputs.
- RMSE, MAE, MaxAE: misfit of resonator-based model vs observed rotation curves.

Three-torus mode inversion:

- n1, n2, n3: integer mode numbers of the three principal directions of the defect
              obtained by inverting the DCT spectrum (k_mean -> n_eff -> (n1,n2,n3)).
- n_eff: effective radial mode (rounded k_mean).
- norm: sqrt(n1^2 + n2^2 + n3^2).
- err: |norm - n_eff| (quality of integer-resonance approximation).

Geometric radii (relative, in units of the largest radius):

- R_rel_1, R_rel_2, R_rel_3: radii ∝ 1/n_j, normalized so max(R_rel_j) = 1.
  These are proxies for relative sizes of the three principal toroidal directions.

Family classification:

- U_family: {U1, U2, U3} determined from (Lphi_over_Rmax, chi6_dimless_Rmax):
  - U1: deep core-dominated, large Lphi_over_Rmax and relatively small chi6;
  - U2: intermediate depth;
  - U3: shallow / strongly modulated (small Lphi_over_Rmax or large chi6).
- G_type: {GA, GB, GC} based on the plateau slope and shape RMSE:
  - GA: negative plateau slope (over-concentrated core);
  - GB: mild positive slopes / broad cores;
  - GC: strongly rising plateaux with small rmse_shape.
- m_mode: integer proxy inferred from SWI (0=nearly axisymmetric, 1/2=more azimuthal structure).
- p_family: {p0,p1,p2} from Q_spec (low/medium/high-Q regimes).

This file closes the loop between observations and the three-torus resonator model:
for each cluster we now have a consistent set of:
- observed rotation-curve diagnostics,
- calibrated field parameters,
- discrete three-torus mode numbers,
- qualitative family labels (U, G, m, p).
