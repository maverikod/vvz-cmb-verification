#!/usr/bin/env python
"""Process Pantheon+ (or JLA) SN Ia tables into a compact Hubble diagram CSV.

Expected input:
  - A raw Pantheon+ table in data_sources/supernovae/, e.g.:
      pantheon_plus_raw.dat
    with at least:
      - z (heliocentric or CMB-frame redshift)
      - mu (distance modulus)
      - mu_err (uncertainty)

Output:
  - data_sources/supernovae/pantheon_plus_hubble_diagram.csv with columns:
      name, z, mu, mu_err
"""

import os
import pathlib
import csv

ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent
SN_DIR = ROOT_DIR / "data_sources" / "supernovae"
OUT_CSV = SN_DIR / "pantheon_plus_hubble_diagram.csv"

def parse_pantheon_plus(path: pathlib.Path):
    """Very generic parser for a whitespace- or comma-separated table.

    You must adapt column indices/names to the actual Pantheon+ file you download.
    """
    rows = []
    if not path.exists():
        print(f"[ERROR] Raw Pantheon+ file not found: {path}")
        return rows

    with path.open("r", encoding="utf-8") as f:
        header = None
        for line in f:
            if not line.strip():
                continue
            if header is None and ("," in line or "name" in line.lower() or "z" in line.lower()):
                header = [h.strip() for h in line.replace("#", "").strip().split()]
                # crude detection; adapt to real file
                continue
            if header is None:
                # skip until we find header
                continue
            parts = line.strip().split()
            if len(parts) < len(header):
                continue
            rec = dict(zip(header, parts))
            # heuristic mapping: adjust names as needed
            name = rec.get("name", rec.get("SN", "SN"))
            z = float(rec.get("zCMB", rec.get("zcmb", rec.get("z", "0"))))
            mu = float(rec.get("MU", rec.get("mu", "0")))
            mu_err = float(rec.get("MUERR", rec.get("mu_err", "0")))
            rows.append(dict(name=name, z=z, mu=mu, mu_err=mu_err))
    return rows

def main():
    SN_DIR.mkdir(parents=True, exist_ok=True)
    raw = SN_DIR / "pantheon_plus_raw.dat"
    rows = parse_pantheon_plus(raw)
    if not rows:
        print("No SN rows parsed. Put Pantheon+ raw file into data_sources/supernovae/ and adapt parser.")
        return

    with OUT_CSV.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["name", "z", "mu", "mu_err"])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    print(f"Wrote Hubble diagram CSV to: {OUT_CSV}")

if __name__ == "__main__":
    main()
