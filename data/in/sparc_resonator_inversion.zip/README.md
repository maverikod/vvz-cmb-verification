# Resonator inversion (n1,n2,n3) from DCT spectrum
Algorithm: n_eff = round(k_mean), minimize |sqrt(n1^2+n2^2+n3^2) - n_eff| over n1,n2,n3 ∈ [1..10].
