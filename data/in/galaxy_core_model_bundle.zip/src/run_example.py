import os, sys
# Ensure local src directory is on path when run as a script
this_dir = os.path.dirname(os.path.abspath(__file__))
if this_dir not in sys.path:
    sys.path.insert(0, this_dir)


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from core_geometry import Torus, Winding, CoreParams
from field_resonator import rotation_curve_from_core, compute_resonator_walls
from halo_gas_from_field import field_from_core, halo_from_field, gas_from_field


def load_cluster_mean_shape(data_dir: str, cluster_id: int = 0):
    """
    Load combined mass/velocity shapes and compute mean rotation curve
    for a given cluster in dimensionless x.

    cluster_id is an integer index; in the CSV 'cluster_col' is of the form 'Cluster_i'.
    """
    path = os.path.join(data_dir, "mass_shapes_all_clusters_combined.csv")
    df = pd.read_csv(path)
    cluster_label = f"Cluster_{cluster_id}"
    df_cluster = df[df["cluster_col"] == cluster_label].copy()
    if df_cluster.empty:
        raise ValueError(f"No rows found for cluster_id={cluster_id} (label={cluster_label})")
    # Use V_fit as smoothed shape if available, otherwise fall back to V_obs
    if "V_fit" in df_cluster.columns:
        V_col = "V_fit"
    elif "V_obs" in df_cluster.columns:
        V_col = "V_obs"
    else:
        # Last resort: first column after x
        V_col = df_cluster.columns[1]
    # Group by x to get average shape
    grouped = df_cluster.groupby("x")[V_col].mean().reset_index()
    x = grouped["x"].values
    V = grouped[V_col].values
    return x, V


def build_simple_core():
    """
    Construct a simple, generic core suitable for a disk galaxy.

    Radii are in units of L_phi (so of order unity).
    """
    # Inner torus: bulge/inner core
    T1 = Torus(
        R=0.2,
        dR=0.05,
        kappa=2.0,
        nx=0.0,
        ny=0.0,
        nz=1.0,
        eps=0.4,
    )
    # Main disk torus
    T2 = Torus(
        R=0.7,
        dR=0.15,
        kappa=3.0,
        nx=0.0,
        ny=0.0,
        nz=1.0,
        eps=0.2,
    )
    # Outer/halo torus
    T3 = Torus(
        R=1.4,
        dR=0.25,
        kappa=1.5,
        nx=0.0,
        ny=0.0,
        nz=1.0,
        eps=0.0,
    )
    winding = Winding(
        m=2,
        pitch=np.deg2rad(15.0),
        handedness=1,
        dphi12=0.0,
        dphi23=0.0,
    )
    return CoreParams(T1=T1, T2=T2, T3=T3, winding=winding)

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "..", "data")

    # Load mean SPARC-like shape for cluster 0
    x, V_obs = load_cluster_mean_shape(data_dir, cluster_id=0)

    # Build a simple core and compute model rotation curve
    core = build_simple_core()
    V_model, walls, modes, A_raw, A_eff = rotation_curve_from_core(
        core, r=x, V_obs=V_obs, n_modes=3
    )

    print("Resonator walls and Q-factor:")
    print(f"  r_in  = {walls.r_in:.3f}")
    print(f"  r_out = {walls.r_out:.3f}")
    print(f"  R_in  = {walls.R_in:.3f}, alpha_in = {walls.alpha_in:.3f}")
    print(f"  R_out = {walls.R_out:.3f}, alpha_out = {walls.alpha_out:.3f}")
    print(f"  Q     = {walls.Q:.2f}")
    print()
    print("Mode amplitudes (raw -> effective):")
    for i, (a_r, a_e) in enumerate(zip(A_raw, A_eff), start=1):
        print(f"  n={i}: A_raw={a_r:.3f}, A_eff={a_e:.3f}")

    # Plot observed vs model rotation curve
    fig, ax = plt.subplots()
    ax.plot(x, V_obs, label="V_obs (cluster mean)")
    ax.plot(x, V_model, linestyle="--", label="V_model (core resonator)")
    ax.set_xlabel("x = r / L_phi")
    ax.set_ylabel("V (normalized units)")
    ax.legend()
    ax.set_title("SPARC cluster mean vs three-torus resonator model")
    plot_path = os.path.join(base_dir, "rotation_curve_fit.png")
    fig.tight_layout()
    fig.savefig(plot_path)
    plt.close(fig)

    # Now build a 3D field and derive halo & gas distributions
    field = field_from_core(core, grid_size=48, extent=2.5)
    rho_halo = halo_from_field(field, beta=2.0)
    rho_gas = gas_from_field(field, cs_ratio=0.15, z_scale=1.0)

    # Save a few 2D slices (z=0 plane) as CSV for inspection
    z_index = len(field.z) // 2
    slice_dict = {
        "x": field.x,
        "y": field.y,
    }
    X, Y = np.meshgrid(field.x, field.y, indexing="ij")
    slice_dict["phi_eff_z0"] = field.phi_eff[:, :, z_index]
    slice_dict["rho_halo_z0"] = rho_halo[:, :, z_index]
    slice_dict["rho_gas_z0"] = rho_gas[:, :, z_index]
    # Flatten into a table
    rows = []
    for i in range(len(field.x)):
        for j in range(len(field.y)):
            rows.append({
                "x": float(X[i, j]),
                "y": float(Y[i, j]),
                "phi_eff_z0": float(slice_dict["phi_eff_z0"][i, j]),
                "rho_halo_z0": float(slice_dict["rho_halo_z0"][i, j]),
                "rho_gas_z0": float(slice_dict["rho_gas_z0"][i, j]),
            })
    df_slice = pd.DataFrame(rows)
    slice_path = os.path.join(base_dir, "field_halo_gas_slice_z0.csv")
    df_slice.to_csv(slice_path, index=False)

if __name__ == "__main__":
    main()
