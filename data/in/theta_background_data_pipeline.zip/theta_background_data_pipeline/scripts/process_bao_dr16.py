#!/usr/bin/env python
"""Process BAO DR16 (and possibly 6dF / WiggleZ) into a unified CSV.

Expected input:
  - One or more BAO measurement files in data_sources/bao/, containing:
      * redshift z_eff
      * distance measure(s): D_M(z)/r_d, H(z) r_d, D_V(z)/r_d, etc.
      * covariance or errors.

Output:
  - data_sources/bao/bao_distance_measurements.csv with columns:
      survey, tracer, z_eff,
      DM_over_rd, DM_over_rd_err,
      H_times_rd, H_times_rd_err,
      DV_over_rd, DV_over_rd_err
"""

import os
import pathlib
import csv
from typing import List, Dict

ROOT_DIR = pathlib.Path(__file__).resolve().parent.parent
BAO_DIR = ROOT_DIR / "data_sources" / "bao"
OUT_CSV = BAO_DIR / "bao_distance_measurements.csv"

def parse_example_dr16(path: pathlib.Path) -> List[Dict]:
    """Example parser stub for a DR16-like table.

    You must adapt it to the actual format you download from SDSS.
    """
    rows: List[Dict] = []
    if not path.exists():
        return rows

    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            parts = line.split()
            try:
                z_eff = float(parts[0])
                dm_over_rd = float(parts[1])
                dm_over_rd_err = float(parts[2])
            except Exception:
                continue
            rows.append(
                dict(
                    survey="BOSS_DR16",
                    tracer="galaxy",
                    z_eff=z_eff,
                    DM_over_rd=dm_over_rd,
                    DM_over_rd_err=dm_over_rd_err,
                    H_times_rd="",
                    H_times_rd_err="",
                    DV_over_rd="",
                    DV_over_rd_err="",
                )
            )
    return rows

def main():
    BAO_DIR.mkdir(parents=True, exist_ok=True)

    all_rows: List[Dict] = []

    dr16_file = BAO_DIR / "dr16_bao_data.txt"
    if dr16_file.exists():
        all_rows.extend(parse_example_dr16(dr16_file))
    else:
        print(f"[WARN] Example DR16 file not found: {dr16_file}")

    if not all_rows:
        print("No BAO rows parsed. Put BAO tables into data_sources/bao/ and edit parsers.")
        return

    fieldnames = [
        "survey",
        "tracer",
        "z_eff",
        "DM_over_rd",
        "DM_over_rd_err",
        "H_times_rd",
        "H_times_rd_err",
        "DV_over_rd",
        "DV_over_rd_err",
    ]

    with OUT_CSV.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in all_rows:
            w.writerow(r)

    print(f"Wrote BAO unified CSV to: {OUT_CSV}")

if __name__ == "__main__":
    main()
