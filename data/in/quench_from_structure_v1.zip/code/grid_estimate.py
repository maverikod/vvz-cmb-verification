
import argparse, json, math, os, numpy as np

C = 299792458.0
MPC = 3.085677581491367e22

def compute(kappa_deg, DM_Mpc, dkfrac, vfrac, z_array):
    Delta_theta_half_rad = math.pi / kappa_deg * (math.pi/180.0)
    L_half = DM_Mpc * Delta_theta_half_rad
    L_full = 2.0 * L_half
    k0 = 2.0*math.pi / L_full
    dk = dkfrac * k0
    delta_comov = 1.0 / max(dk,1e-30)
    rows = []
    for z in z_array:
        a = 1.0/(1.0+z)
        tau_s = (delta_comov*a*MPC)/(max(vfrac,1e-12)*C)
        rows.append([z, L_full*a, delta_comov*a, tau_s])
    return np.array(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kappa", type=float, required=True)
    ap.add_argument("--DM", type=float, required=True)
    ap.add_argument("--dkfrac", type=float, required=True)
    ap.add_argument("--vfrac", type=float, required=True)
    ap.add_argument("--out", default="outputs/grid.json")
    args = ap.parse_args()
    z = np.logspace(2, 12, 80)  # from z=1e2 to 1e12
    mat = compute(args.kappa, args.DM, args.dkfrac, args.vfrac, z)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    out = {"kappa_deg": args.kappa, "DM_Mpc": args.DM, "dkfrac": args.dkfrac, "vfrac": args.vfrac,
           "columns": ["z", "L_full_phys_Mpc", "delta_phys_Mpc", "tau_lower_s"], "rows": mat.tolist()}
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(json.dumps({"rows": len(mat)}))

if __name__=="__main__":
    main()
