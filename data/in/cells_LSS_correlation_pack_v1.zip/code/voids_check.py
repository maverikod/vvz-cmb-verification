
import numpy as np, json, os, math, argparse

def read_voids(path):
    if os.path.exists(path):
        Reff = np.loadtxt(path, delimiter=",", skiprows=1)
        if Reff.ndim>1: Reff = Reff[:,0]
    else:
        # synthetic: bimodal around 10 and 18 Mpc
        rng = np.random.default_rng(2)
        Reff = np.concatenate([rng.normal(10,2,400), rng.normal(18,3,300)])
        Reff = Reff[(Reff>2)&(Reff<40)]
    return Reff

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--voids", default="data/voids.csv")
    ap.add_argument("--L_half", type=float, default=11.5)
    ap.add_argument("--L_full", type=float, default=23.0)
    ap.add_argument("--out", default="outputs/voids_check.json")
    args = ap.parse_args()
    Reff = read_voids(args.voids)
    med = float(np.median(Reff)); mode_est = float(np.percentile(Reff, 50))  # crude; could use KDE
    overlap = float(np.mean((Reff>0.7*args.L_half) & (Reff<1.3*args.L_full)))
    res = {"median_R": med, "mode_est": mode_est, "overlap_fraction_Lhalf_to_Lfull": overlap,
           "L_half": args.L_half, "L_full": args.L_full, "n": int(len(Reff))}
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(json.dumps(res))

if __name__=="__main__":
    main()
