
import numpy as np
from dataclasses import dataclass
from core_geometry import CoreParams

@dataclass
class FieldGrid:
    x: np.ndarray
    y: np.ndarray
    z: np.ndarray
    phi_eff: np.ndarray  # effective potential or proxy

def field_from_core(core: CoreParams, grid_size: int = 64, extent: float = 3.0) -> FieldGrid:
    """
    Very simplified 3D effective potential from three tori.

    We approximate each torus as producing a softened 1/R potential
    concentrated around its ring radius in its local plane.
    """
    # Cartesian grid
    x = np.linspace(-extent, extent, grid_size)
    y = np.linspace(-extent, extent, grid_size)
    z = np.linspace(-extent, extent, grid_size)
    X, Y, Z = np.meshgrid(x, y, z, indexing="ij")

    phi = np.zeros_like(X, dtype=float)

    def add_torus_potential(torus, sign=1.0):
        n = torus.normal_vector()
        # Decompose position into components parallel and perpendicular to the torus plane
        # Plane normal is n; project r onto n to get height, subtract to get in-plane component.
        r_vec = np.stack([X, Y, Z], axis=-1)  # shape (..., 3)
        n_vec = n.reshape((1, 1, 1, 3))
        proj = np.sum(r_vec * n_vec, axis=-1, keepdims=True) * n_vec
        in_plane = r_vec - proj
        # Distance from torus center ring (radius R in plane)
        R_xy = np.linalg.norm(in_plane, axis=-1)
        # Softened distance to torus ring
        dr = np.sqrt((R_xy - torus.R) ** 2 + np.linalg.norm(proj, axis=-1) ** 2 + torus.dR ** 2)
        # Contribution ~ kappa / dr
        return sign * torus.kappa / dr

    # Superpose contributions from three tori
    phi += add_torus_potential(core.T1)
    phi += add_torus_potential(core.T2)
    phi += add_torus_potential(core.T3)

    # Simple normalization
    phi -= np.min(phi)
    phi /= (np.max(phi) + 1e-9)

    return FieldGrid(x=x, y=y, z=z, phi_eff=phi)

def halo_from_field(field: FieldGrid, beta: float = 2.0) -> np.ndarray:
    """
    Build a toy halo density distribution from the effective field.

    beta controls how strongly density concentrates in low-phi regions.
    """
    # Use an exponential of -beta * phi as a proxy for a stationary distribution.
    rho = np.exp(-beta * field.phi_eff)
    # Normalize
    rho /= np.mean(rho)
    return rho

def gas_from_field(field: FieldGrid, cs_ratio: float = 0.1, z_scale: float = 1.0) -> np.ndarray:
    """
    Build a toy gas density distribution from the effective field.

    cs_ratio imitates "temperature" (higher -> thicker gas disk).
    z_scale controls how strongly vertical direction is weighted.
    """
    X, Y, Z = np.meshgrid(field.x, field.y, field.z, indexing="ij")
    R = np.sqrt(X**2 + Y**2)
    # Favor regions of strong in-plane gradient in phi (spiral arms / bars)
    # Compute approximate gradient in plane
    dphi_dx = np.gradient(field.phi_eff, field.x, axis=0)
    dphi_dy = np.gradient(field.phi_eff, field.y, axis=1)
    grad_in_plane = np.sqrt(dphi_dx**2 + dphi_dy**2)
    grad_in_plane /= (np.max(grad_in_plane) + 1e-9)

    # Vertical scale via Gaussian with scale ~ cs_ratio * z_scale
    hz = cs_ratio * z_scale
    vertical_factor = np.exp(-(Z**2) / (2.0 * hz**2))

    # Gas density peaks where field gradients are strong (spiral/bar features)
    # and vertical factor is large.
    rho_gas = grad_in_plane * vertical_factor
    # Avoid zero-density everywhere
    rho_gas += 1e-6
    rho_gas /= np.mean(rho_gas)
    return rho_gas
