
import numpy as np
from dataclasses import dataclass

@dataclass
class Torus:
    """
    Simple parameterization of one torus in the galactic core.

    All radii are in dimensionless units (e.g. r / L_phi).
    """
    R: float              # central radius of the torus
    dR: float             # radial half-width of the torus region
    kappa: float          # stiffness / energy weight of this torus
    nx: float             # x-component of normal
    ny: float             # y-component of normal
    nz: float             # z-component of normal
    eps: float = 0.0      # ellipticity of cross-section (bar-ness)

    def normal_vector(self) -> np.ndarray:
        v = np.array([self.nx, self.ny, self.nz], dtype=float)
        n = np.linalg.norm(v)
        if n == 0:
            return np.array([0.0, 0.0, 1.0])
        return v / n


@dataclass
class Winding:
    """
    Global winding (obmotka) parameters.
    """
    m: int                # number of spiral arms
    pitch: float          # pitch angle (radians, >0)
    handedness: int       # +1 or -1
    dphi12: float = 0.0   # phase shift between T1 and T2
    dphi23: float = 0.0   # phase shift between T2 and T3


@dataclass
class CoreParams:
    """
    Three-torus core + winding. This is what we vary in the inverse problem.
    """
    T1: Torus
    T2: Torus
    T3: Torus
    winding: Winding

    def sorted_radii(self):
        Rs = sorted([self.T1.R, self.T2.R, self.T3.R])
        return Rs
