
import numpy as np, json, os, math, argparse

def savgol(y, win=31, poly=3):
    # simple Savitzky–Golay (no SciPy): naive convolution with polynomial fit per window
    # fallback: moving average if window too small
    n = len(y); win = max(5, int(win)|1)  # odd
    half = win//2
    out = np.zeros(n)
    x = np.arange(-half, half+1)
    V = np.vstack([x**p for p in range(poly+1)]).T
    Vinv = np.linalg.pinv(V)
    for i in range(n):
        i0 = max(0, i-half); i1 = min(n-1, i+half)
        seg = y[i0:i1+1]
        xloc = np.arange(i0-i, i1-i+1)
        Vloc = np.vstack([xloc**p for p in range(poly+1)]).T
        coef = np.linalg.lstsq(Vloc, seg, rcond=None)[0]
        out[i] = coef[0]  # value at x=0
    return out

def read_pk(path):
    if os.path.exists(path):
        k, P = np.loadtxt(path, delimiter=",", skiprows=1).T
    else:
        # synthetic: smooth P(k) with a weak ring bump near k0
        rng = np.random.default_rng(1)
        k = np.linspace(0.02, 0.6, 600)
        P0 = 1e4 * k**-1.6 * np.exp(-k/0.5)
        k0 = 0.273
        bump = 1.0 + 0.05*np.exp(-0.5*((k-k0)/0.05)**2)
        P = P0*bump*(1.0 + 0.02*rng.normal(size=k.size))
    return k, P

def band_snr(k, P, k0=0.273, bw=0.06):
    # whiten by smooth baseline
    baseline = savgol(P, win=41, poly=3)
    R = (P - baseline) / (baseline + 1e-30)
    sel = (k>k0-bw) & (k<k0+bw)
    mu = float(R[sel].mean()); std = float(R[~sel].std()+1e-12)
    return mu/std, mu, std

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pk", default="data/Pk.csv")
    ap.add_argument("--k0", type=float, default=0.273)
    ap.add_argument("--bw", type=float, default=0.06)
    ap.add_argument("--out", default="outputs/Pk_ring.json")
    args = ap.parse_args()
    k, P = read_pk(args.pk)
    snr, mu, std = band_snr(k, P, args.k0, args.bw)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"k0": args.k0, "bw": args.bw, "snr": float(snr), "band_mean": mu, "noise_std": std}, f, ensure_ascii=False, indent=2)
    print(json.dumps({"snr": float(snr)}))

if __name__=="__main__":
    main()
