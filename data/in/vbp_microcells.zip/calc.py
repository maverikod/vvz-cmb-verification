
import math

k_per_deg = 66.8345  # κ in deg^-1

deg_to_rad = math.pi/180
rad_to_deg = 180/math.pi

k_per_rad = k_per_deg * rad_to_deg

Delta_theta_deg_half = math.pi / k_per_deg
Delta_theta_deg_full = 2*math.pi / k_per_deg

Delta_theta_arcmin_half = Delta_theta_deg_half * 60
Delta_theta_arcmin_full = Delta_theta_deg_full * 60

ell_star = k_per_rad

D_M_Mpc = 14000.0
z_star = 1100.0
a_star = 1.0/(1.0+z_star)

Delta_theta_rad_half = Delta_theta_deg_half * deg_to_rad
Delta_theta_rad_full = Delta_theta_deg_full * deg_to_rad

s_com_half_Mpc = D_M_Mpc * Delta_theta_rad_half
s_com_full_Mpc = D_M_Mpc * Delta_theta_rad_full

s_phys_half_Mpc = s_com_half_Mpc * a_star
s_phys_full_Mpc = s_com_full_Mpc * a_star

print(f"kappa: {k_per_deg:.4f} deg^-1 = {k_per_rad:.1f} rad^-1")
print(f"Delta_theta_half: {Delta_theta_deg_half:.5f} deg = {Delta_theta_arcmin_half:.2f} arcmin")
print(f"Delta_theta_full: {Delta_theta_deg_full:.5f} deg = {Delta_theta_arcmin_full:.2f} arcmin")
print(f"ell*: ~ {ell_star:.0f}")
print(f"s_half: {s_com_half_Mpc:.2f} Mpc (comoving), {s_phys_half_Mpc*1000:.1f} kpc (proper @ z~1100)")
print(f"s_full: {s_com_full_Mpc:.2f} Mpc (comoving), {s_phys_full_Mpc*1000:.1f} kpc (proper @ z~1100)")
