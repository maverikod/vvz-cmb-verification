# Quench parameters from oscillatory structure — v1

Build: 2025-11-08 14:42 UTC

This pack estimates **quench parameters** from a measured oscillatory scale and spectral width.

## Inputs (example in `example_config.json`)
- `kappa_deg` : angular oscillation wavenumber (deg^-1), e.g. 66.8345
- `DM_Mpc`    : comoving distance to the projection shell (Mpc). For CMB LSS shell use ~14000 Mpc.
- `delta_k_over_k` : fractional spectral width of the ring (Δk/k0) in 3D comoving units.
- `v_frac`    : freeze-out front speed as a fraction of c (0 < v_frac ≤ 1).
- `z_list`    : list of candidate imprint redshifts z_q to evaluate (comoving length is invariant; this sets physical scales and τ_q bounds).

## Core relations (comoving unless noted)
- Half-period on the sky: Δθ_0.5 = π / κ_*  [radians].
- L_half = DM * Δθ_0.5; L_full = 2 * L_half;  k0 = 2π / L_full.
- Ring width: Δk = (Δk/k0) * k0  →  domain-wall thickness (comoving) δ ≈ 1/Δk.
- Quench duration lower bound:  τ_q(z) ≥ (a(z) * δ) / (v_frac * c),  with a=1/(1+z).
  (Assumes freeze-out front limited by speed v_frac·c; gives **lower bound** on duration.)
- Physical lengths at z: L_phys(z) = L_comov / (1+z).

Optional notional energy:
- E_q ~ ħ / τ_q  (characteristic frequency scale).

## Running
1) Edit `example_config.json` (insert your measured Δk/k and preferred z grid).
2) Run:
   python code/infer_quench.py --config example_config.json
3) See `outputs/results.json` and `outputs/tau_vs_z.png`.

You can also sweep parameters:
   python code/grid_estimate.py --kappa 66.8345 --DM 14000 --dkfrac 0.10 --vfrac 1.0

Notes:
- If you only know κ_* but not Δk/k, you still get **length scales** (L_half, L_full, k0).
- τ_q requires Δk/k (from ring width in P(k) or from κ-spectrum width). Use instrument-deconvolved widths.
